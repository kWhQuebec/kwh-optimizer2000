#!/bin/bash
# =============================================================
# kWh Québec - PDF Generator V2 Deploy Script
# =============================================================
# Usage: Run from your repo root (kwh-optimizer2000/)
#
#   tar xzf kwh-pdf-v2.tar.gz
#   bash DEPLOY.sh
#
# This will:
# 1. Copy pdfGeneratorV2.ts to server/pdf/
# 2. Copy preview-rapport.html to client/public/
# 3. Copy INTEGRATION_GUIDE.md to root
# 4. Stage and commit changes
# =============================================================

set -e

echo "🔧 kWh PDF Generator V2 - Deploying..."

# Verify we're in the right repo
if [ ! -f "replit.nix" ] && [ ! -f "package.json" ]; then
  echo "❌ Error: Run this script from the repo root (kwh-optimizer2000/)"
  exit 1
fi

# Check files exist
for f in server/pdf/pdfGeneratorV2.ts client/public/preview-rapport.html INTEGRATION_GUIDE.md; do
  if [ ! -f "$f" ]; then
    echo "❌ Missing: $f — Did you extract the tar.gz first?"
    exit 1
  fi
done

echo "✅ Files verified"
echo ""
echo "📁 Files deployed:"
echo "   server/pdf/pdfGeneratorV2.ts    (13 pages, brand kWh Québec)"
echo "   client/public/preview-rapport.html (preview visuelle)"
echo "   INTEGRATION_GUIDE.md            (guide d'intégration)"
echo ""

# Git operations
read -p "🔀 Stage and commit? (y/n) " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
  git add server/pdf/pdfGeneratorV2.ts client/public/preview-rapport.html INTEGRATION_GUIDE.md
  git commit -m "feat(pdf): PDF Generator V2 — 13 pages, brand kWh Québec

- Nouvelle structure 13 pages (vs 11 avant)
- Ajout pages: Qui Sommes-Nous, Profil Énergétique, Stockage & Optimisation
- Incitatifs corrigés: ITC 30% (Loi C-69) + HQ Autoproduction 1000\$/kW
- Contact corrigé: evaluation@kwh.quebec / 514-427-8871
- Stats corrigés: 120+ MW, 25+ projets, 15+ ans
- Ajout batterie BESS (BYD), KB Racking dans équipements
- Ajout LCOE, rendement spécifique, code tarifaire HQ
- Funnel 4 étapes aligné site web + FAQ
- Interfaces TypeScript: BatteryConfig, EnergyProfile
- Support images base64: logo, satellite, logos clients"
  echo ""
  echo "✅ Commit created!"
  echo "   Run 'git push' when ready."
else
  echo "ℹ️  Files are in place. Stage/commit manually when ready."
fi

echo ""
echo "📋 Next steps:"
echo "   1. Add logo kWh (reverse blanc) → server/assets/logo-white.png"
echo "   2. Add logos clients → server/assets/client-logos/"
echo "   3. Wire up battery + energyProfile data in your API endpoint"
echo "   4. Test: open client/public/preview-rapport.html in browser"
echo ""
echo "🎉 Done!"
